- 👋 Hi, My discord: @[Just] Freak#4999
- ❤️ Learning Python, All my Mods can be found here (BombSquad v1.7+)
- 🔥 Press [![Download zip](https://custom-icon-badges.herokuapp.com/badge/-Download-blue?style=for-the-badge&logo=download&logoColor=white "Download zip")](https://github.com/Freaku17/BombSquad-Mods-byFreaku/archive/refs/heads/main.zip) 

Then extract and copy paste *the files* in your BombSquad folder.

###### All Gamemodes are supported on servers!

### 🎯 Mods:
* Gamemodes: 5
   * Frozen One
   * Icy Emits
   * Volley Ball
   * Musical Flags
   * Memory Game

* Utilities: 4
   * Floater
      * Type /floater in-game to use
   * IconsKeyboard
      * Enable "Always Use Internal Keyboard" in settings/advanced and double-tap keyboard's space bar
   * Terminal
      * Shows error of the mod you're working on (read instructions in-file)
   * TowerD-Unlocked
      * Unlocks TowerD map to use in Teams/FFA
